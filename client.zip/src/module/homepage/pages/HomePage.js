import Index from "../container/homepage";

const  Homepage=()=><Index/>

export default Homepage